
@extends('welcome')
@section('title')

        <title>Bootstrap News Template - Free HTML Templates</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Bootstrap News Template - Free HTML Templates" name="keywords">
        <meta content="Bootstrap News Template - Free HTML Templates" name="description">
  


@endsection

@section('body')

 
<br>

<!-- Tab News Start-->
        <div class="tab-news">
            <div class="container">
            	  @include('add')
                <div class="row">
                    <div class="col-md-6">
                        <ul class="nav nav-pills nav-justified">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="pill" href="#featured">Youtube Video</a>
                            </li>

                            <?php 
					         $massage = Session::get('massage');
					         
					         if($massage){  ?>
					          <h4 class="alert alert-success"> <?php echo $massage; ?>  </h4>
					          <?php   Session::put('massage',NULL); } ?> 
					                             
					                        </ul>

                        <div class="tab-content">
                            
                                  <form action="{{URL('save-general-post')}}"  method="post"   enctype="multipart/form-data">

                                  	 {{csrf_field()}}
							    <div class="form-group">
							        <label for="inputEmail">Post Title</label>
							        <input type="text" name="post_title"  required="" class="form-control" id="inputEmail" placeholder="Enter Post Title">
							    </div>

							    <div class="form-group">
							        <label for="inputEmail">Post Image</label>
							        <input type="file" name="post_category_photo"  required="" class="form-control" id="inputEmail"  >
							    </div>
							    
							    <div class="form-group">
							        <label for="inputPassword"> Post Deteles </label> <br>
							        <textarea class="massage" name="post_deteles" class="form-control"   type="textarea" id="message" placeholder="Enter Post Description "     required> </textarea>
							    </div>

							    <div class="form-group">
							     <br>
							        <label for="inputPassword"> Post Tags </label> <br>
							        <textarea class="massage" name="post_tag" class="form-control"   type="textarea" id="message" placeholder="Enter Post Tags "     required> </textarea>
							    </div>

							    
							     
							    <button type="submit" class="btn btn-primary">Submit Post</button>
							</form>   
                                </div>
                             
                            
                    </div>
                </div>

            </div>
        </div>
        <!-- Tab News Start-->




 @endsection 