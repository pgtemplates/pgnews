<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateVisaimposTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('visaimpos', function (Blueprint $table) {
           $table->increments('visaimpo_id');
           $table->string('visaimpo_country_name');
           $table->string('visaimpo_vaisa_type');
           $table->text('visaimpo_vaisa_deteles');
           $table->string('visaimpo_type')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('visaimpos');
    }
}
