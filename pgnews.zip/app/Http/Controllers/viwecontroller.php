<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class viwecontroller extends Controller
{
    public function pgnews(){
    return view('deteles');
  }

}
