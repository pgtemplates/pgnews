<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use DB;
use Mail;
use App\Http\Requests;
use Session;
Session_start();
use Socialite;

class home extends Controller
{

   function fontpageuserchack(){
      $admin_id = Session::get('user_id');
      if($admin_id){
        return;
      }else{
        return Redirect::to('user-login')->send();
      }
    }


   
  public function pgnews(){
    return view('layout');
  }

  public function userlogin()
    {
        return view('loginpage');
    }

public function savenewuser(Request $request)
    {
         

       $date = array();
       $date['user_name'] = 'PG News';
       $date['user_email'] = $request->user_email;

       $useemail = $request->user_email;

       $user_ids= DB::table('allusers')->where('user_email',$useemail)->limit(1)->first();

         if($user_ids){

          Session::put('user_id', $user_ids->user_id);
       
          Session::put('user_email', $useemail);

          return Redirect::to('pg-news-home');
       }else{
           DB::table('allusers')->insertGetId($date);
          $dfd=  DB::table('allusers')->where('user_email',$useemail)->limit(1)->get();
          foreach($dfd as $dfd){
               $dfa=  $dfd->user_id;
               Session::put('user_id', $dfa);
          }
           
           
           Session::put('user_email', $useemail);

           return Redirect::to('pg-news-home');

       }
    }

 public function userlogout(){
      Session::flush();

     return Redirect::to('pg-news-home');
   }



  public function youtubepost(){
    $this->fontpageuserchack();
  	return view('youtube');
  }

 public function saveyoutubevideo(Request $request){
  $this->fontpageuserchack();
  $customer = Session::get('user_id');

 	$date = array();
 	$date['post_title'] = $request->youtube_title;
 	$date['post_deteles']  = $request->youtube_link;
 	$date['post_user_id'] = $customer;
  $date['post_type'] = 2;
  $date['post_tag'] = 2;
  $date['post_category_photo'] = 2;


   DB::table('posts')->insertGetId($date);

   Session::put('massage',' Secessfully Update your Video . ');

   return Redirect::to('youtube-post');

 }


 public function generalpost(){
   $this->fontpageuserchack();
  return view('generalpost');
 }

 public function savegeneralpost(Request $request){
  $this->fontpageuserchack();
  $customer = Session::get('user_id');

  $date=array();
           $date['post_title']=$request->post_title;
           $date['post_deteles']=$request->post_deteles;
           $date['post_tag']=$request->post_tag;
           $date['post_user_id']= $customer;

           



            $image= $request->file('post_category_photo');
        
        if($image){
            $image_name = rand();
            $ext = strtolower($image->getClientOriginalExtension());
            $image_fullName = $image_name.'.'. $ext;
            $upload_path = 'image/';
            $image_url= $upload_path.$image_fullName;
            $secc=$image->move($upload_path,$image_fullName);
            if($secc){
                $date['post_category_photo']= $image_url;

         DB::table('posts')->insert($date);
         
         
        
          Session::put('massage','Post Inserted Successfully ! . ');
         return Redirect::to('general-post');        
            }
            
        }
           
 }

 public function deteles($post_id){
  $post = DB::table('posts')
                 ->where('post_id',$post_id)
                 ->first();
      return view('deteles')->with('post',$post);
 
 }

public function userprofile(){
  $this->fontpageuserchack();
 
  return view('userprofile');
}

public function editpost($post_id){
  $this->fontpageuserchack();
  $customer = Session::get('user_id');
  $post = DB::table('posts')->where('post_id',$post_id)->where('post_user_id',$customer)->delete();
  return Redirect::to('user-profile');

}
public function deleteyoutube($youtube_id){
  $this->fontpageuserchack();
  $customer = Session::get('user_id');
  $post = DB::table('youtubeposts')->where('youtube_id',$youtube_id)->where('youtube_user_id',$customer)->delete();
  return Redirect::to('user-profile');

}

public function serachpgnews(Request $request){
   $this->validate($request ,[
           'serach_pgnews' => 'required'
      ]);
  $serach_text = $request->serach_pgnews;

   $serch = DB::table('posts')
          ->orderBy('post_id','desc')
          ->where('post_title','like','%'.$serach_text.'%')
          ->get();
    return view('search')->with('serch',$serch); 
}

 public function addvisaimpro(){
  $this->fontpageuserchack();
  $customer = Session::get('user_id');
  if($customer==2){
     return view('addvisaimpro');
   }else{
    return Redirect::to('pg-news-home');
   }
 
 }

 public function savevisapost(Request $request){
  $date = array();
  $date['visaimpo_country_name'] = $request->visaimpo_country_name;
  $date['visaimpo_vaisa_type']   = $request->visaimpo_vaisa_type;
  $date['visaimpo_vaisa_deteles']= $request->visaimpo_vaisa_deteles;

  DB::table('visaimpos')->insert($date);
  Session::put('massage',' Secessfully Update your post . ');
  return Redirect::to('add-visa-impro');
 
 }

 public function viewvisaimpro(Request $request){
   

  $visaimpo_country_name = $request->visaimpo_country_name;
  $visaimpo_vaisa_type = $request->visaimpo_vaisa_type;
 

  $visad = DB::table('visaimpos')
          ->where('visaimpo_country_name',$visaimpo_country_name)
          ->where('visaimpo_vaisa_type',$visaimpo_vaisa_type)
          ->get();
  
  return view('visaimpro')->with('visa',$visad);
  
  }



}
