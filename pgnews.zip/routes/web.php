<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\home;
use App\Http\Controllers\PostController;
 

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('layout');
});


Route::get("pg-news-home", [home::class,'pgnews'])->name('pg-news-home');

 

 Route::get('youtube-post', [home::class,'youtubepost'])->name('youtube-post');
 
 Route::post('save-youtube-video', [home::class,'saveyoutubevideo'])->name('save-youtube-video');

 Route::get('user-login', [home::class,'userlogin'])->name('user-login');

 Route::post('save-new-user', [home::class,'savenewuser'])->name('save-new-user');

 Route::get('user-logout', [home::class,'userlogout'])->name('user-logout');

 Route::get('general-post', [home::class,'generalpost'])->name('general-post');

 Route::post('save-general-post', [home::class,'savegeneralpost'])->name('save-general-post');

 Route::get('Deteles-pgnews/{post_id}-{post_title}', [home::class,'deteles'])->name('Deteles-pgnews');

 Route::get('user-profile', [home::class,'userprofile'])->name('user-profile');

 Route::get('edit_post/{post_id}', [home::class,'editpost'])->name('edit_post');

 Route::get('delete_youtube/{youtube_id}', [home::class,'deleteyoutube'])->name('delete_youtube');

 Route::get('serach-pgnews', [home::class,'serachpgnews'])->name('serach-pgnews');

 Route::get('add-visa-impro', [home::class,'addvisaimpro'])->name('add-visa-impro');

 Route::post('save-visa-post', [home::class,'savevisapost'])->name('save-visa-post');

 Route::post('view-visa-impro', [home::class,'viewvisaimpro'])->name('view-visa-impro');

 


 