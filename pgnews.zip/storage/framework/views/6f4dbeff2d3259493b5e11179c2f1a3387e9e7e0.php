<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- auto -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-6311547005217511"
     data-ad-slot="9303233668"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script><?php /**PATH C:\xampp\htdocs\pgnews\resources\views/add.blade.php ENDPATH**/ ?>