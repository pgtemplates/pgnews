

<?php $__env->startSection('title'); ?>

        <title><?php echo e($post->post_title); ?></title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="<?php echo e($post->post_tag); ?>" name="keywords">
        <meta content=" <?php echo e($post->post_deteles); ?>" name="description">
  


<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

 <!-- Single News Start-->
        <div class="single-news">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="sn-container">
                            <div class="sn-img">
                                <img src="<?php echo e(url($post->post_category_photo)); ?>" />
                            </div>
                            <div class="sn-content">
                                <h1 class="sn-title"><?php echo e($post->post_title); ?></h1>
                               <?php echo $post->post_deteles; ?>

                               
                            </div>
                        </div>
                        <div class="sn-related">
                            <h2>Related News</h2>
                            <div class="row sn-slider">
  <?php 
$po2 = DB::table('posts')
           ->orderby('post_id','desc')
           ->where('post_type',0)
           ->paginate(10);
foreach ($po2 as $po) {
    
 

?>                   <?php 
$str = $po->post_title;
$final = preg_replace('#[ -]+#', '-', $str);  

                                    ?>

                                <div class="col-md-4">
                                    <div class="sn-img">
                                        <img height="200px" src="<?php echo e(url($po->post_category_photo)); ?>" />
                                        <div class="sn-title">
                                            <a href="<?php echo e(url('Deteles-pgnews', $po->post_id.'-'.$final)); ?>"><?php echo e($po->post_title); ?></a>
                                        </div>
                                    </div>
                                </div>

       <?php } ?>                                 
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="sidebar">
                            <div class="sidebar-widget">
                                <h2 class="sw-title">Recent Posts</h2>
                                <div class="news-list">
                                	 <?php 
$po2 = DB::table('posts')
           ->orderby('post_id','desc')
           ->where('post_type',0)
           ->paginate(10);
foreach ($po2 as $po) {
    
 

?>                   <?php 
$str = $po->post_title;
$final = preg_replace('#[ -]+#', '-', $str);  

                                    ?>

                                    <div class="nl-item">
                                        <div class="nl-img">
                                            <img src="<?php echo e(url($po->post_category_photo)); ?>" />
                                        </div>
                                        <div class="nl-title">
                                            <a href="<?php echo e(url('Deteles-pgnews', $po->post_id.'-'.$final)); ?>"><?php echo e($po->post_title); ?></a>
                                        </div>
                                    </div>


    <?php } ?>   
                                   
                                </div>
                            </div>
                            
                            <div class="sidebar-widget">
                                <div class="image">
                                    <a href="https://htmlcodex.com"><img src="<?php echo e(asset('fontpage/img/ads-2.jpg')); ?>" alt="Image"></a>
                                </div>
                            </div>
                            
                             
                            
                            
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Single News End-->        





 <?php $__env->stopSection(); ?> 
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pgnews\resources\views/deteles.blade.php ENDPATH**/ ?>