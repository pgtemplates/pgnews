

<?php $__env->startSection('title'); ?>

        <title>Bootstrap News Template - Free HTML Templates</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="Bootstrap News Template - Free HTML Templates" name="keywords">
        <meta content="Bootstrap News Template - Free HTML Templates" name="description">
  


<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

 
<br>

<!-- Tab News Start-->
        <div class="tab-news">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <ul class="nav nav-pills nav-justified">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="pill" href="#featured">Youtube Video</a>
                            </li>

                            <?php 
					         $massage = Session::get('massage');
					         
					         if($massage){  ?>
					          <h4 class="alert alert-success"> <?php echo $massage; ?>  </h4>
					          <?php   Session::put('massage',NULL); } ?> 
					                             
					                        </ul>

                        <div class="tab-content">
                            
                                  <form action="<?php echo e(URL('save-youtube-video')); ?>"  method="post" >

                                  	 <?php echo e(csrf_field()); ?>

							    <div class="form-group">
							        <label for="inputEmail">Video Title</label>
							        <input type="test" name="youtube_title"  required="" class="form-control" id="inputEmail" placeholder="Enter Video Title">
							    </div>
							    <div class="form-group">
							        <label for="inputPassword">Video Link</label>
							        <input type="text" required="" name="youtube_link" class="form-control" id="inputPassword" placeholder="Enter video link">
							    </div>
							     
							    <button type="submit" class="btn btn-primary">Submit</button>
							</form>   
                                </div>
                             
                            
                    </div>
                </div>
            </div>
        </div>
        <!-- Tab News Start-->




 <?php $__env->stopSection(); ?> 
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pgnews\resources\views/youtube.blade.php ENDPATH**/ ?>