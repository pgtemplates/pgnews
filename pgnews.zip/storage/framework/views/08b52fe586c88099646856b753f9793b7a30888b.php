<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
            <?php echo $__env->yieldContent('title'); ?>

            <script data-ad-client="ca-pub-6311547005217511" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>

        <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
  <script>tinymce.init({selector:'textarea'});</script>
  

        <!-- Favicon -->
        <link href="<?php echo e(asset('fontpage/img/favicon.ico')); ?>" rel="icon">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,600&display=swap" rel="stylesheet"> 

        <!-- CSS Libraries -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="<?php echo e(asset('fontpage/lib/slick/slick.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('fontpage/lib/slick/slick-theme.css')); ?>" rel="stylesheet">
<link  href="https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz&display=swap" rel="stylesheet">
  
  <link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
        <!-- Template Stylesheet -->
        <link href="<?php echo e(asset('fontpage/css/style.css')); ?>" rel="stylesheet">
    </head>

    <body>
        <!-- Top Bar Start -->
        <div class="top-bar">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="tb-contact">
                            <p><i class="fas fa-envelope"></i>info@mail.com</p>
                            <p><i class="fas fa-phone-alt"></i>+012 345 6789</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="tb-menu">
                             
                            <a href="">You can download our App</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Top Bar Start -->
        
        <!-- Brand Start -->
        <div class="brand">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-3 col-md-4">
                        <div class="b-logo">
                            <a href="<?php echo e(route('pg-news-home')); ?>">
                              <h3 style="
     
    font-size: 2.5em;
    font-family: 'Lobster', cursive;
    font-weight: 600;
    color:#a26868;
">PG News</h3>  
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-4">
                        <div class="b-ads">
                            <a href="#">
                              <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<ins class="adsbygoogle"
     style="display:block"
     data-ad-format="fluid"
     data-ad-layout-key="-f7+6b-2g-5t+jt"
     data-ad-client="ca-pub-6311547005217511"
     data-ad-slot="4054657862"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4">
                        <div class="b-search">
                            <form action="<?php echo e(url('serach-pgnews')); ?>" method="get">
                                
                           
                            <input type="text" name="serach_pgnews" placeholder="Search">
                            <button><i class="fa fa-search"></i></button>
                             </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Brand End -->

        <!-- Nav Bar Start -->
        <div class="nav-bar">
            <div class="container">
                <nav class="navbar navbar-expand-md bg-dark navbar-dark">
                    <a href="#" class="navbar-brand">MENU</a>
                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                        <div class="navbar-nav mr-auto">
                            <a href="<?php echo e(route('pg-news-home')); ?>" class="nav-item nav-link active">Home</a>
                            <div class="nav-item dropdown">
                                <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Create Post</a>
                                <div class="dropdown-menu">
                                    <a href="<?php echo e(url('youtube-post')); ?>" class="dropdown-item">Youtube Video</a>
                                    <a href="<?php echo e(url('general-post')); ?>" class="dropdown-item">General Post</a>
                                </div>
                            </div>
                            <a href="<?php echo e(url('user-profile')); ?> " class="nav-item nav-link">Profile</a>

                         

                    
<?php 
        $customer = Session::get('user_id');

        
      ?>    
                 
     <?php if($customer): ?>
            <a href="<?php echo e(url('user-logout')); ?>" class="nav-item nav-link">Logout</a>
     <?php else: ?>
      <a href="<?php echo e(url('user-login')); ?>" class="nav-item nav-link">Login</a>
      <?php endif; ?> 


                        </div>
                        <div class="social ml-auto">
                            <a target="_blank" href="https://twitter.com/pgtemplates"><i class="fab fa-twitter"></i></a>
                            <a target="_blank" href="https://web.facebook.com/helpnewsfik"><i class="fab fa-facebook-f"></i></a>
                            <a target="_blank" href="https://www.linkedin.com/feed/?trk=nav_logo"><i class="fab fa-linkedin-in"></i></a>
                            <a target="_blank" href="https://www.youtube.com/channel/UCqfW04RjFb_cR8TgNoOdXoA"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </nav>

            </div>
        </div>
        <!-- Nav Bar End -->

       <?php echo $__env->yieldContent('body'); ?>

        <!-- Footer Start -->
        <div class="footer">
            <div class="container">
                 <?php echo $__env->make('add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="footer-widget">
                            <h3 class="title">Get in Touch</h3>
                            <div class="contact-info">
                                <p><i class="fa fa-map-marker"></i>123 News Street, NY, USA</p>
                                <p><i class="fa fa-envelope"></i>info@example.com</p>
                                <p><i class="fa fa-phone"></i>+123-456-7890</p>
                                <div class="social">
                                      <a target="_blank" href="https://twitter.com/pgtemplates"><i class="fab fa-twitter"></i></a>
                            <a target="_blank" href="https://web.facebook.com/helpnewsfik"><i class="fab fa-facebook-f"></i></a>
                            <a target="_blank" href="https://www.linkedin.com/feed/?trk=nav_logo"><i class="fab fa-linkedin-in"></i></a>
                            <a target="_blank" href="https://www.youtube.com/channel/UCqfW04RjFb_cR8TgNoOdXoA"><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div   class="col-lg-3 col-md-6">
                        <div  class="footer-widget" >
                            <h3 class="title">General Post</h3>

                            <ul >
                                <?php 
$post = DB::table('posts')
           ->orderby('post_id','desc')
           ->where('post_type',0)
           ->limit(5)
           ->get();
foreach ($post as $post) {
 

  
    
$str = $post->post_title;
  
$final = preg_replace('#[ -]+#', '-', $str); 


?>
                                <li><a href="<?php echo e(url('Deteles-pgnews', $post->post_id.'-'.$final)); ?>"><?php echo e($post->post_title); ?></a></li>
   <?php } ?>                             
                            </ul>  
                        
                        </div>
                    </div>

                      <div   class="col-lg-3 col-md-6">
                        <div  class="footer-widget" >
                            <h3 class="title">Youtube Video</h3>

                            <ul >
                                <?php 
$post = DB::table('posts')
           ->orderby('post_id','desc')
           ->where('post_type',2)
           ->limit(5)
           ->get();
foreach ($post as $post) {
 

  
    
$str = $post->post_title;
  
$final = preg_replace('#[ -]+#', '-', $str); 


?>
                                <li><a href="<?php echo e(url('Deteles-pgnews', $post->post_id.'-'.$final)); ?>"><?php echo e($post->post_title); ?></a></li>
   <?php } ?>                             
                            </ul>  
                        
                        </div>
                    </div>

                     
                    
                    <div  class="col-lg-3 col-md-6">
                        <div class="footer-widget">
                            <h3 class="title">Newsletter</h3>
                            <div class="newsletter">
                                <p>
                                    আমরা সর্বদাই চেষ্টা করি বিদেশের যত নিউজ আছে সবকিছু প্রতিনিয়ত আপডেট দিয়ে যেতেন যেমন কিভাবে কোন দেশে যেতে হয় কোন দেশের ভিসা কিভাবে হয় কোন দেশের ভিসা কিভাবে রিনুয়াল করা হয় এবং ইউরোপ আমেরিকা এবং সকল দেশের নিউজ নিয়ে আমরা সর্বদাই থাকে এবং সব সময় নতুন নতুন আপডেট নিয়ে আসি তাই আপনি যদি বিদেশ থাকেন 
                                </p>
                                <form>
                                    <input class="form-control" type="email" placeholder="Your email here">
                                    <button class="btn">Submit</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->
        
        <!-- Footer Menu Start  
        <div class="footer-menu">
            <div class="container">
                <div class="f-menu">
                    <a href="">Terms of use</a>
                    <a href="">Privacy policy</a>
                    <a href="">Cookies</a>
                    <a href="">Accessibility help</a>
                    <a href="">Advertise with us</a>
                    <a href="">Contact us</a>
                </div>
            </div>
        </div>
       Footer Menu End -->

        <!-- Footer Bottom Start -->
        <div class="footer-bottom">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 copyright">
                        <p>Copyright &copy; <a href="https://pgtemplates.com">PG News</a>. All Rights Reserved</p>
                    </div>

                    <div class="col-md-6 template-by">
                        <p>Template By <a href="https://pgtemplates.com">PG Templates</a></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer Bottom End -->

        <!-- Back to Top -->
        <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

        <!-- JavaScript Libraries -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo e(asset('fontpage/lib/easing/easing.min.js')); ?>"></script>
        <script src="<?php echo e(asset('fontpage/lib/slick/slick.min.js')); ?>"></script>

        <!-- Template Javascript -->
        <script src="<?php echo e(asset('fontpage/js/main.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\pgnews\resources\views/welcome.blade.php ENDPATH**/ ?>